// ============================================================
// EditorPanel Component
// Full-featured editor with tabs for Template, Content,
// Design, Sections (drag-and-drop), and Export
// ============================================================

import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  Layout, Type, Palette, Layers, Download,
  GripVertical, Trash2, ChevronDown, ChevronRight,
  Copy, ExternalLink, FileText, Image, Link as LinkIcon,
  Minus, Share2, Bold, Italic, Underline, List,
  ListOrdered, Upload, X, Mail, AlignLeft,
  Strikethrough, RotateCcw, Heading1, Eye
} from 'lucide-react';
import {
  EmailConfig, EmailSection, SectionType,
  TemplatePreset, templatePresets, fontOptions
} from '../types';
import { generateEmailHtml } from '../utils/generateEmail';

// ---- Props ----
interface EditorPanelProps {
  config: EmailConfig;
  setConfig: React.Dispatch<React.SetStateAction<EmailConfig>>;
  onToast: (msg: string) => void;
}

// ---- Tab Definition ----
const tabs = [
  { id: 'templates', label: 'Templates', icon: Layout },
  { id: 'content', label: 'Content', icon: Type },
  { id: 'design', label: 'Design', icon: Palette },
  { id: 'sections', label: 'Sections', icon: Layers },
  { id: 'export', label: 'Export', icon: Download },
];

// ---- Section type definitions for the builder palette ----
const sectionTypes: { type: SectionType; label: string; icon: React.ElementType; color: string }[] = [
  { type: 'text', label: 'Text', icon: AlignLeft, color: '#3b82f6' },
  { type: 'image', label: 'Image', icon: Image, color: '#8b5cf6' },
  { type: 'button', label: 'Button', icon: LinkIcon, color: '#10b981' },
  { type: 'divider', label: 'Divider', icon: Minus, color: '#f59e0b' },
  { type: 'social', label: 'Social', icon: Share2, color: '#ec4899' },
];

// ---- Helper: create a new section with default content ----
function createSection(type: SectionType): EmailSection {
  const id = `s-${Date.now()}-${Math.random().toString(36).substring(2, 8)}`;
  switch (type) {
    case 'text':
      return { id, type, content: { text: 'Enter your text content here...' } };
    case 'image':
      return { id, type, content: { src: '', alt: 'Image description' } };
    case 'button':
      return { id, type, content: { buttonText: 'Learn More', url: 'https://example.com' } };
    case 'divider':
      return { id, type, content: { color: '#e5e7eb' } };
    case 'social':
      return {
        id, type, content: {
          links: [
            { platform: 'Facebook', url: '' },
            { platform: 'Twitter', url: '' },
            { platform: 'LinkedIn', url: '' },
            { platform: 'Instagram', url: '' },
            { platform: 'YouTube', url: '' },
          ]
        }
      };
    default:
      return { id, type: 'text', content: { text: '' } };
  }
}

// ---- Section type badge colors ----
const sectionBadgeColors: Record<SectionType, string> = {
  text: 'bg-blue-100 text-blue-700',
  image: 'bg-purple-100 text-purple-700',
  button: 'bg-emerald-100 text-emerald-700',
  divider: 'bg-amber-100 text-amber-700',
  social: 'bg-pink-100 text-pink-700',
};

// ============================================================
// EditorPanel Component
// ============================================================
export const EditorPanel: React.FC<EditorPanelProps> = ({ config, setConfig, onToast }) => {
  const [activeTab, setActiveTab] = useState('content');
  const [editorKey, setEditorKey] = useState(0);
  const [dragIndex, setDragIndex] = useState<number | null>(null);
  const [dragOverIndex, setDragOverIndex] = useState<number | null>(null);
  const [expandedSectionId, setExpandedSectionId] = useState<string | null>(null);
  const [htmlMode, setHtmlMode] = useState(false);
  const editorRef = useRef<HTMLDivElement>(null);

  // ---- Initialize rich text editor content ----
  useEffect(() => {
    if (editorRef.current) {
      editorRef.current.innerHTML = config.body;
    }
  }, [editorKey]); // eslint-disable-line react-hooks/exhaustive-deps

  // ---- Config update helper ----
  const updateConfig = useCallback(<K extends keyof EmailConfig>(key: K, value: EmailConfig[K]) => {
    setConfig(prev => ({ ...prev, [key]: value }));
  }, [setConfig]);

  // ---- Section helpers ----
  const addSection = (type: SectionType) => {
    const section = createSection(type);
    updateConfig('sections', [...config.sections, section]);
    setExpandedSectionId(section.id);
  };

  const removeSection = (id: string) => {
    updateConfig('sections', config.sections.filter(s => s.id !== id));
    if (expandedSectionId === id) setExpandedSectionId(null);
  };

  const updateSectionContent = (id: string, contentUpdate: Partial<EmailSection['content']>) => {
    updateConfig('sections', config.sections.map(s =>
      s.id === id ? { ...s, content: { ...s.content, ...contentUpdate } } : s
    ));
  };

  const updateSocialLink = (sectionId: string, index: number, url: string) => {
    const section = config.sections.find(s => s.id === sectionId);
    if (!section || !section.content.links) return;
    const newLinks = [...section.content.links];
    newLinks[index] = { ...newLinks[index], url };
    updateSectionContent(sectionId, { links: newLinks });
  };

  // ---- Rich text editor commands ----
  const execCommand = (command: string, value?: string) => {
    document.execCommand(command, false, value || '');
    editorRef.current?.focus();
    if (editorRef.current) {
      updateConfig('body', editorRef.current.innerHTML);
    }
  };

  const insertLink = () => {
    const url = prompt('Enter URL:');
    if (url) execCommand('createLink', url);
  };

  const handleEditorInput = () => {
    if (editorRef.current) {
      updateConfig('body', editorRef.current.innerHTML);
    }
  };

  // ---- Template application ----
  const applyTemplate = (preset: TemplatePreset) => {
    setConfig(prev => ({
      ...prev,
      template: preset.id,
      themeColor: preset.themeColor,
      fontFamily: preset.fontFamily,
      headerBgColor: preset.headerBgColor,
      buttonColor: preset.buttonColor,
      buttonTextColor: preset.buttonTextColor,
    }));
    setEditorKey(k => k + 1);
    onToast(`✨ ${preset.name} template applied!`);
  };

  // ---- Image upload handler ----
  const handleImageUpload = (field: 'logoImage' | 'bannerImage') => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) {
        if (file.size > 2 * 1024 * 1024) {
          onToast('⚠️ Image must be under 2MB');
          return;
        }
        const reader = new FileReader();
        reader.onload = (ev) => {
          updateConfig(field, ev.target?.result as string);
          onToast(`🖼️ ${field === 'logoImage' ? 'Logo' : 'Banner'} uploaded!`);
        };
        reader.readAsDataURL(file);
      }
    };
    input.click();
  };

  // ---- Section image upload ----
  const handleSectionImageUpload = (sectionId: string) => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) {
        if (file.size > 2 * 1024 * 1024) {
          onToast('⚠️ Image must be under 2MB');
          return;
        }
        const reader = new FileReader();
        reader.onload = (ev) => {
          updateSectionContent(sectionId, { src: ev.target?.result as string });
        };
        reader.readAsDataURL(file);
      }
    };
    input.click();
  };

  // ---- Drag & Drop handlers ----
  const handleDragStart = (index: number) => setDragIndex(index);
  const handleDragEnter = (index: number) => setDragOverIndex(index);
  const handleDragOver = (e: React.DragEvent) => e.preventDefault();
  const handleDragEnd = () => {
    if (dragIndex !== null && dragOverIndex !== null && dragIndex !== dragOverIndex) {
      const newSections = [...config.sections];
      const [removed] = newSections.splice(dragIndex, 1);
      newSections.splice(dragOverIndex, 0, removed);
      updateConfig('sections', newSections);
    }
    setDragIndex(null);
    setDragOverIndex(null);
  };

  // ---- Export handlers ----
  const handleCopyHtml = async () => {
    const html = generateEmailHtml(config);
    try {
      await navigator.clipboard.writeText(html);
      onToast('✅ HTML copied to clipboard!');
    } catch {
      const textarea = document.createElement('textarea');
      textarea.value = html;
      textarea.style.position = 'fixed';
      textarea.style.opacity = '0';
      document.body.appendChild(textarea);
      textarea.select();
      document.execCommand('copy');
      document.body.removeChild(textarea);
      onToast('✅ HTML copied to clipboard!');
    }
  };

  const handleDownloadHtml = () => {
    const html = generateEmailHtml(config);
    const blob = new Blob([html], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `email-${config.template}-template.html`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    onToast('📥 HTML file downloaded!');
  };

  const handleExportAll = () => {
    const html = generateEmailHtml(config);
    const output = `<!--\n  Email Subject: ${config.subject}\n  Sender: ${config.senderName}\n  Template: ${config.template}\n  Generated: ${new Date().toISOString()}\n-->\n${html}`;
    const blob = new Blob([output], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `email-complete-${Date.now()}.html`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    onToast('📦 Subject + body exported!');
  };

  const handlePreviewNewTab = () => {
    const html = generateEmailHtml(config);
    const win = window.open('', '_blank');
    if (win) {
      win.document.write(html);
      win.document.close();
    }
  };

  // ============================================================
  // TAB RENDERERS
  // ============================================================

  // ---- TEMPLATES TAB ----
  const renderTemplatesTab = () => (
    <div className="space-y-4">
      <div>
        <h3 className="text-sm font-semibold text-gray-800 mb-1">Choose a Template</h3>
        <p className="text-xs text-gray-500">Select a pre-designed template. Customize colors and fonts in the Design tab.</p>
      </div>
      <div className="grid grid-cols-2 gap-3">
        {templatePresets.map((preset) => (
          <button
            key={preset.id}
            onClick={() => applyTemplate(preset)}
            className={`template-card text-left border-2 rounded-xl overflow-hidden transition-all ${
              config.template === preset.id
                ? 'border-blue-500 shadow-lg ring-2 ring-blue-200'
                : 'border-gray-200 hover:border-gray-300'
            }`}
          >
            {/* Mini preview */}
            <div style={{ backgroundColor: preset.headerBgColor }} className="h-14 flex flex-col items-center justify-center px-3 relative">
              <div className="w-14 h-1.5 bg-white/40 rounded mb-1.5"></div>
              <div className="w-20 h-2 bg-white/60 rounded"></div>
              {config.template === preset.id && (
                <div className="absolute top-1.5 right-1.5 w-5 h-5 bg-white rounded-full flex items-center justify-center">
                  <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                </div>
              )}
            </div>
            <div className="p-2.5 bg-white">
              <div className="h-1.5 bg-gray-200 rounded w-3/4 mb-1.5"></div>
              <div className="h-1 bg-gray-100 rounded w-full mb-1"></div>
              <div className="h-1 bg-gray-100 rounded w-5/6 mb-2"></div>
              <div className="flex justify-center">
                <div style={{ backgroundColor: preset.buttonColor }} className="h-3.5 w-14 rounded-sm"></div>
              </div>
            </div>
            <div className="px-2.5 pb-2.5 bg-white border-t border-gray-100">
              <h4 className="font-semibold text-xs text-gray-800">{preset.name}</h4>
              <p className="text-[10px] text-gray-500 leading-tight mt-0.5">{preset.description}</p>
            </div>
          </button>
        ))}
      </div>
    </div>
  );

  // ---- CONTENT TAB ----
  const renderContentTab = () => (
    <div className="space-y-5">
      {/* Email Subject */}
      <div>
        <label className="flex items-center gap-1.5 text-sm font-semibold text-gray-700 mb-1.5">
          <Mail size={14} className="text-gray-400" />
          Email Subject
        </label>
        <input
          type="text"
          value={config.subject}
          onChange={(e) => updateConfig('subject', e.target.value)}
          className="w-full px-3 py-2.5 border border-gray-200 rounded-lg text-sm bg-white"
          placeholder="Enter email subject line..."
        />
      </div>

      {/* Heading */}
      <div>
        <label className="flex items-center gap-1.5 text-sm font-semibold text-gray-700 mb-1.5">
          <Heading1 size={14} className="text-gray-400" />
          Email Heading
        </label>
        <input
          type="text"
          value={config.heading}
          onChange={(e) => updateConfig('heading', e.target.value)}
          className="w-full px-3 py-2.5 border border-gray-200 rounded-lg text-sm bg-white"
          placeholder="Enter main heading..."
        />
      </div>

      {/* Body - Rich Text Editor */}
      <div>
        <div className="flex items-center justify-between mb-1.5">
          <label className="flex items-center gap-1.5 text-sm font-semibold text-gray-700">
            <AlignLeft size={14} className="text-gray-400" />
            Email Body
          </label>
          <button
            onClick={() => setHtmlMode(!htmlMode)}
            className="flex items-center gap-1 text-xs text-gray-500 hover:text-gray-700 px-2 py-1 rounded bg-gray-100 hover:bg-gray-200 transition-colors"
          >
            {htmlMode ? <Eye size={12} /> : <span>&lt;/&gt;</span>}
            {htmlMode ? 'Visual' : 'HTML'}
          </button>
        </div>

        {htmlMode ? (
          // HTML source mode
          <textarea
            value={config.body}
            onChange={(e) => {
              updateConfig('body', e.target.value);
              setEditorKey(k => k + 1);
            }}
            className="w-full px-3 py-2.5 border border-gray-200 rounded-lg text-sm bg-gray-50 font-mono"
            rows={10}
            placeholder="Enter HTML content..."
          />
        ) : (
          // Visual rich text mode
          <div className="border border-gray-200 rounded-lg overflow-hidden bg-white">
            {/* Toolbar */}
            <div className="flex flex-wrap items-center gap-0.5 px-2 py-1.5 bg-gray-50 border-b border-gray-200">
              <button onClick={() => execCommand('bold')} className="toolbar-btn p-1.5 rounded" title="Bold">
                <Bold size={14} className="text-gray-600" />
              </button>
              <button onClick={() => execCommand('italic')} className="toolbar-btn p-1.5 rounded" title="Italic">
                <Italic size={14} className="text-gray-600" />
              </button>
              <button onClick={() => execCommand('underline')} className="toolbar-btn p-1.5 rounded" title="Underline">
                <Underline size={14} className="text-gray-600" />
              </button>
              <button onClick={() => execCommand('strikeThrough')} className="toolbar-btn p-1.5 rounded" title="Strikethrough">
                <Strikethrough size={14} className="text-gray-600" />
              </button>
              <div className="w-px h-5 bg-gray-300 mx-1" />
              <button onClick={() => execCommand('insertUnorderedList')} className="toolbar-btn p-1.5 rounded" title="Bullet List">
                <List size={14} className="text-gray-600" />
              </button>
              <button onClick={() => execCommand('insertOrderedList')} className="toolbar-btn p-1.5 rounded" title="Numbered List">
                <ListOrdered size={14} className="text-gray-600" />
              </button>
              <div className="w-px h-5 bg-gray-300 mx-1" />
              <button onClick={insertLink} className="toolbar-btn p-1.5 rounded" title="Insert Link">
                <LinkIcon size={14} className="text-gray-600" />
              </button>
              <button onClick={() => execCommand('removeFormat')} className="toolbar-btn p-1.5 rounded" title="Clear Formatting">
                <RotateCcw size={14} className="text-gray-600" />
              </button>
            </div>
            {/* Editable area */}
            <div
              key={editorKey}
              ref={editorRef}
              contentEditable
              suppressContentEditableWarning
              onInput={handleEditorInput}
              className="rich-editor px-3 py-3"
              data-placeholder="Write your email body content here..."
            />
          </div>
        )}
      </div>

      {/* Footer Text */}
      <div>
        <label className="flex items-center gap-1.5 text-sm font-semibold text-gray-700 mb-1.5">
          <FileText size={14} className="text-gray-400" />
          Footer Text
        </label>
        <textarea
          value={config.footerText}
          onChange={(e) => updateConfig('footerText', e.target.value)}
          className="w-full px-3 py-2.5 border border-gray-200 rounded-lg text-sm bg-white resize-none"
          rows={2}
          placeholder="Enter footer text..."
        />
      </div>

      {/* Sender Name */}
      <div>
        <label className="flex items-center gap-1.5 text-sm font-semibold text-gray-700 mb-1.5">
          <Mail size={14} className="text-gray-400" />
          Sender Name
        </label>
        <input
          type="text"
          value={config.senderName}
          onChange={(e) => updateConfig('senderName', e.target.value)}
          className="w-full px-3 py-2.5 border border-gray-200 rounded-lg text-sm bg-white"
          placeholder="Your company or sender name..."
        />
      </div>
    </div>
  );

  // ---- DESIGN TAB ----
  const renderDesignTab = () => (
    <div className="space-y-6">
      {/* Colors Section */}
      <div>
        <h3 className="text-sm font-semibold text-gray-800 mb-3 flex items-center gap-1.5">
          <Palette size={14} className="text-gray-400" />
          Colors
        </h3>
        <div className="space-y-3">
          {/* Theme Color */}
          <div className="flex items-center gap-3">
            <input type="color" value={config.themeColor} onChange={(e) => updateConfig('themeColor', e.target.value)} className="w-10 h-10 shrink-0" />
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-gray-700">Theme Color</p>
              <p className="text-xs text-gray-400 font-mono">{config.themeColor}</p>
            </div>
          </div>
          {/* Header Background */}
          <div className="flex items-center gap-3">
            <input type="color" value={config.headerBgColor} onChange={(e) => updateConfig('headerBgColor', e.target.value)} className="w-10 h-10 shrink-0" />
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-gray-700">Header Background</p>
              <p className="text-xs text-gray-400 font-mono">{config.headerBgColor}</p>
            </div>
          </div>
          {/* Button Color */}
          <div className="flex items-center gap-3">
            <input type="color" value={config.buttonColor} onChange={(e) => updateConfig('buttonColor', e.target.value)} className="w-10 h-10 shrink-0" />
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-gray-700">Button Color</p>
              <p className="text-xs text-gray-400 font-mono">{config.buttonColor}</p>
            </div>
          </div>
          {/* Button Text Color */}
          <div className="flex items-center gap-3">
            <input type="color" value={config.buttonTextColor} onChange={(e) => updateConfig('buttonTextColor', e.target.value)} className="w-10 h-10 shrink-0" />
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-gray-700">Button Text Color</p>
              <p className="text-xs text-gray-400 font-mono">{config.buttonTextColor}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Typography Section */}
      <div>
        <h3 className="text-sm font-semibold text-gray-800 mb-3 flex items-center gap-1.5">
          <Type size={14} className="text-gray-400" />
          Typography
        </h3>
        <select
          value={config.fontFamily}
          onChange={(e) => updateConfig('fontFamily', e.target.value)}
          className="w-full px-3 py-2.5 border border-gray-200 rounded-lg text-sm bg-white"
        >
          {fontOptions.map((f) => (
            <option key={f.value} value={f.value}>{f.label}</option>
          ))}
        </select>
        <p className="text-xs text-gray-400 mt-1">Web-safe fonts for maximum email client compatibility.</p>
      </div>

      {/* Images Section */}
      <div>
        <h3 className="text-sm font-semibold text-gray-800 mb-3 flex items-center gap-1.5">
          <Image size={14} className="text-gray-400" />
          Images
        </h3>
        <div className="space-y-4">
          {/* Logo */}
          <div>
            <p className="text-sm font-medium text-gray-700 mb-2">Logo Image</p>
            {config.logoImage ? (
              <div className="relative inline-block group">
                <img src={config.logoImage} alt="Logo preview" className="h-14 object-contain border border-gray-200 rounded-lg p-2 bg-gray-50" />
                <button
                  onClick={() => updateConfig('logoImage', '')}
                  className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-0.5 shadow-md opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  <X size={12} />
                </button>
              </div>
            ) : (
              <button
                onClick={() => handleImageUpload('logoImage')}
                className="flex items-center gap-2 px-4 py-3 border-2 border-dashed border-gray-300 rounded-lg hover:bg-gray-50 hover:border-gray-400 transition-colors text-sm text-gray-600 w-full justify-center"
              >
                <Upload size={16} />
                Upload Logo (max 2MB)
              </button>
            )}
          </div>
          {/* Banner */}
          <div>
            <p className="text-sm font-medium text-gray-700 mb-2">Banner Image</p>
            {config.bannerImage ? (
              <div className="relative group">
                <img src={config.bannerImage} alt="Banner preview" className="w-full h-24 object-cover border border-gray-200 rounded-lg" />
                <button
                  onClick={() => updateConfig('bannerImage', '')}
                  className="absolute top-1 right-1 bg-red-500 text-white rounded-full p-1 shadow-md opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  <X size={12} />
                </button>
              </div>
            ) : (
              <button
                onClick={() => handleImageUpload('bannerImage')}
                className="flex items-center gap-2 px-4 py-3 border-2 border-dashed border-gray-300 rounded-lg hover:bg-gray-50 hover:border-gray-400 transition-colors text-sm text-gray-600 w-full justify-center"
              >
                <Upload size={16} />
                Upload Banner (max 2MB)
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );

  // ---- SECTIONS TAB ----
  const renderSectionsTab = () => (
    <div className="space-y-5">
      {/* Add section palette */}
      <div>
        <h3 className="text-sm font-semibold text-gray-800 mb-2">Add Content Section</h3>
        <p className="text-xs text-gray-500 mb-3">Click to add a section. Drag to reorder below.</p>
        <div className="grid grid-cols-5 gap-2">
          {sectionTypes.map((st) => (
            <button
              key={st.type}
              onClick={() => addSection(st.type)}
              className="add-section-btn flex flex-col items-center gap-1.5 p-3 border border-gray-200 rounded-xl hover:bg-gray-50 transition-all"
            >
              <div
                className="w-8 h-8 rounded-lg flex items-center justify-center"
                style={{ backgroundColor: st.color + '15', color: st.color }}
              >
                <st.icon size={16} />
              </div>
              <span className="text-[10px] font-medium text-gray-600">{st.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Section list */}
      <div>
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-sm font-semibold text-gray-800">
            Content Sections {config.sections.length > 0 && <span className="text-gray-400 font-normal">({config.sections.length})</span>}
          </h3>
          {config.sections.length > 0 && (
            <button
              onClick={() => { updateConfig('sections', []); setExpandedSectionId(null); }}
              className="text-xs text-red-500 hover:text-red-700 transition-colors"
            >
              Clear All
            </button>
          )}
        </div>

        {config.sections.length === 0 ? (
          <div className="text-center py-10 border-2 border-dashed border-gray-200 rounded-xl">
            <Layers size={32} className="mx-auto mb-2 text-gray-300" />
            <p className="text-sm text-gray-400">No sections added yet</p>
            <p className="text-xs text-gray-300 mt-1">Click the buttons above to add content</p>
          </div>
        ) : (
          <div className="space-y-2">
            {config.sections.map((section, index) => {
              const isExpanded = expandedSectionId === section.id;
              const isDragging = dragIndex === index;
              const isDragOver = dragOverIndex === index;

              return (
                <div
                  key={section.id}
                  draggable
                  onDragStart={() => handleDragStart(index)}
                  onDragEnter={() => handleDragEnter(index)}
                  onDragOver={handleDragOver}
                  onDragEnd={handleDragEnd}
                  className={`section-card border rounded-xl bg-white overflow-hidden ${
                    isDragging ? 'dragging' : ''
                  } ${isDragOver && dragIndex !== index ? 'drag-over' : ''} ${
                    isExpanded ? 'border-blue-200 shadow-sm' : 'border-gray-200'
                  }`}
                >
                  {/* Section header */}
                  <div
                    className="flex items-center gap-2 px-3 py-2.5 cursor-pointer hover:bg-gray-50 transition-colors"
                    onClick={() => setExpandedSectionId(isExpanded ? null : section.id)}
                  >
                    <GripVertical size={14} className="text-gray-300 cursor-grab shrink-0" />
                    <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${sectionBadgeColors[section.type]}`}>
                      {section.type.toUpperCase()}
                    </span>
                    <span className="text-xs text-gray-500 flex-1 truncate">
                      {section.type === 'text' && (section.content.text?.substring(0, 30) || 'Text block')}
                      {section.type === 'image' && (section.content.alt || 'Image')}
                      {section.type === 'button' && (section.content.buttonText || 'Button')}
                      {section.type === 'divider' && 'Horizontal divider'}
                      {section.type === 'social' && 'Social links'}
                    </span>
                    <button
                      onClick={(e) => { e.stopPropagation(); removeSection(section.id); }}
                      className="p-1 text-gray-400 hover:text-red-500 rounded transition-colors shrink-0"
                    >
                      <Trash2 size={13} />
                    </button>
                    {isExpanded
                      ? <ChevronDown size={14} className="text-gray-400 shrink-0" />
                      : <ChevronRight size={14} className="text-gray-400 shrink-0" />
                    }
                  </div>

                  {/* Section editor (expanded) */}
                  {isExpanded && (
                    <div className="px-3 pb-3 pt-1 border-t border-gray-100 space-y-3">
                      {/* TEXT SECTION EDITOR */}
                      {section.type === 'text' && (
                        <div>
                          <label className="text-xs font-medium text-gray-600 mb-1 block">Text Content <span className="text-gray-400">(HTML supported)</span></label>
                          <textarea
                            value={section.content.text || ''}
                            onChange={(e) => updateSectionContent(section.id, { text: e.target.value })}
                            className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm resize-none"
                            rows={4}
                            placeholder="Enter text content..."
                          />
                        </div>
                      )}

                      {/* IMAGE SECTION EDITOR */}
                      {section.type === 'image' && (
                        <>
                          <div>
                            <label className="text-xs font-medium text-gray-600 mb-1 block">Image Source</label>
                            <div className="flex gap-2">
                              <input
                                type="text"
                                value={section.content.src || ''}
                                onChange={(e) => updateSectionContent(section.id, { src: e.target.value })}
                                className="flex-1 px-3 py-2 border border-gray-200 rounded-lg text-sm"
                                placeholder="Enter image URL..."
                              />
                              <button
                                onClick={() => handleSectionImageUpload(section.id)}
                                className="px-3 py-2 bg-gray-100 hover:bg-gray-200 rounded-lg text-sm transition-colors shrink-0"
                                title="Upload image"
                              >
                                <Upload size={14} />
                              </button>
                            </div>
                          </div>
                          <div>
                            <label className="text-xs font-medium text-gray-600 mb-1 block">Alt Text</label>
                            <input
                              type="text"
                              value={section.content.alt || ''}
                              onChange={(e) => updateSectionContent(section.id, { alt: e.target.value })}
                              className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm"
                              placeholder="Image description..."
                            />
                          </div>
                          {section.content.src && (
                            <img src={section.content.src} alt={section.content.alt} className="w-full h-24 object-cover rounded-lg border border-gray-200" />
                          )}
                        </>
                      )}

                      {/* BUTTON SECTION EDITOR */}
                      {section.type === 'button' && (
                        <>
                          <div>
                            <label className="text-xs font-medium text-gray-600 mb-1 block">Button Text</label>
                            <input
                              type="text"
                              value={section.content.buttonText || ''}
                              onChange={(e) => updateSectionContent(section.id, { buttonText: e.target.value })}
                              className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm"
                              placeholder="Button label..."
                            />
                          </div>
                          <div>
                            <label className="text-xs font-medium text-gray-600 mb-1 block">Button URL</label>
                            <input
                              type="text"
                              value={section.content.url || ''}
                              onChange={(e) => updateSectionContent(section.id, { url: e.target.value })}
                              className="w-full px-3 py-2 border border-gray-200 rounded-lg text-sm"
                              placeholder="https://..."
                            />
                          </div>
                          <div className="flex items-center justify-center py-2">
                            <span
                              className="inline-block px-6 py-2 text-sm font-semibold rounded-md"
                              style={{ backgroundColor: config.buttonColor, color: config.buttonTextColor }}
                            >
                              {section.content.buttonText || 'Button'}
                            </span>
                          </div>
                        </>
                      )}

                      {/* DIVIDER SECTION EDITOR */}
                      {section.type === 'divider' && (
                        <div>
                          <label className="text-xs font-medium text-gray-600 mb-1 block">Divider Color</label>
                          <div className="flex items-center gap-3">
                            <input
                              type="color"
                              value={section.content.color || '#e5e7eb'}
                              onChange={(e) => updateSectionContent(section.id, { color: e.target.value })}
                              className="w-8 h-8"
                            />
                            <div className="flex-1 border-t-2" style={{ borderColor: section.content.color || '#e5e7eb' }} />
                          </div>
                        </div>
                      )}

                      {/* SOCIAL SECTION EDITOR */}
                      {section.type === 'social' && section.content.links && (
                        <div className="space-y-2">
                          <p className="text-xs text-gray-500">Enter URLs for the platforms you want to include. Leave empty to exclude.</p>
                          {section.content.links.map((link, i) => (
                            <div key={link.platform} className="flex items-center gap-2">
                              <span className="text-xs font-medium text-gray-600 w-20 shrink-0">{link.platform}</span>
                              <input
                                type="text"
                                value={link.url}
                                onChange={(e) => updateSocialLink(section.id, i, e.target.value)}
                                className="flex-1 px-3 py-1.5 border border-gray-200 rounded-lg text-xs"
                                placeholder={`https://${link.platform.toLowerCase()}.com/...`}
                              />
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );

  // ---- EXPORT TAB ----
  const renderExportTab = () => (
    <div className="space-y-5">
      <div>
        <h3 className="text-sm font-semibold text-gray-800 mb-1">Export Your Email</h3>
        <p className="text-xs text-gray-500">Generate clean, inline-CSS HTML ready for email clients.</p>
      </div>

      {/* Subject preview */}
      <div className="bg-gray-50 rounded-xl p-4 border border-gray-200">
        <p className="text-xs font-medium text-gray-500 mb-1">Subject Line</p>
        <p className="text-sm font-semibold text-gray-800">{config.subject || '(no subject)'}</p>
        <p className="text-xs text-gray-400 mt-1">From: {config.senderName || '(no sender)'}</p>
      </div>

      {/* Action buttons */}
      <div className="space-y-3">
        <button
          onClick={handleCopyHtml}
          className="export-btn w-full flex items-center gap-3 px-4 py-3.5 bg-blue-600 text-white rounded-xl font-medium text-sm hover:bg-blue-700 transition-colors"
        >
          <div className="w-9 h-9 bg-blue-500 rounded-lg flex items-center justify-center shrink-0">
            <Copy size={16} />
          </div>
          <div className="text-left">
            <p className="font-semibold">Copy HTML to Clipboard</p>
            <p className="text-xs text-blue-200">Copy email HTML for pasting into email platforms</p>
          </div>
        </button>

        <button
          onClick={handleDownloadHtml}
          className="export-btn w-full flex items-center gap-3 px-4 py-3.5 bg-emerald-600 text-white rounded-xl font-medium text-sm hover:bg-emerald-700 transition-colors"
        >
          <div className="w-9 h-9 bg-emerald-500 rounded-lg flex items-center justify-center shrink-0">
            <Download size={16} />
          </div>
          <div className="text-left">
            <p className="font-semibold">Download as .html File</p>
            <p className="text-xs text-emerald-200">Save the email template as a standalone HTML file</p>
          </div>
        </button>

        <button
          onClick={handleExportAll}
          className="export-btn w-full flex items-center gap-3 px-4 py-3.5 bg-purple-600 text-white rounded-xl font-medium text-sm hover:bg-purple-700 transition-colors"
        >
          <div className="w-9 h-9 bg-purple-500 rounded-lg flex items-center justify-center shrink-0">
            <FileText size={16} />
          </div>
          <div className="text-left">
            <p className="font-semibold">Export Subject + Body</p>
            <p className="text-xs text-purple-200">Download HTML with subject and sender metadata</p>
          </div>
        </button>

        <button
          onClick={handlePreviewNewTab}
          className="export-btn w-full flex items-center gap-3 px-4 py-3.5 bg-gray-700 text-white rounded-xl font-medium text-sm hover:bg-gray-800 transition-colors"
        >
          <div className="w-9 h-9 bg-gray-600 rounded-lg flex items-center justify-center shrink-0">
            <ExternalLink size={16} />
          </div>
          <div className="text-left">
            <p className="font-semibold">Preview in New Tab</p>
            <p className="text-xs text-gray-400">Open the email in a new browser tab</p>
          </div>
        </button>
      </div>

      {/* Compatibility note */}
      <div className="bg-amber-50 border border-amber-200 rounded-xl p-3">
        <p className="text-xs font-semibold text-amber-700 mb-1">📧 Email Compatibility</p>
        <p className="text-xs text-amber-600 leading-relaxed">
          Generated HTML uses inline CSS and table-based layout for compatibility with Gmail, Outlook, Apple Mail, and Yahoo Mail.
          Images use data URIs for preview — for production, host images on a web server.
        </p>
      </div>
    </div>
  );

  // ============================================================
  // MAIN RENDER
  // ============================================================
  return (
    <div className="h-full flex flex-col bg-white">
      {/* Tab navigation */}
      <div className="flex border-b border-gray-200 bg-gray-50/80 shrink-0 overflow-x-auto">
        {tabs.map((tab) => {
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-1.5 px-3 py-3 text-xs font-medium whitespace-nowrap transition-all border-b-2 ${
                isActive
                  ? 'border-blue-600 text-blue-600 bg-white'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:bg-gray-100'
              }`}
            >
              <tab.icon size={14} />
              <span className="hidden sm:inline">{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Tab content */}
      <div className="flex-1 overflow-y-auto p-4">
        {activeTab === 'templates' && renderTemplatesTab()}
        {activeTab === 'content' && renderContentTab()}
        {activeTab === 'design' && renderDesignTab()}
        {activeTab === 'sections' && renderSectionsTab()}
        {activeTab === 'export' && renderExportTab()}
      </div>
    </div>
  );
};
