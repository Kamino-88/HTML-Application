// ============================================================
// PreviewPanel Component
// Live preview of the generated email with responsive toggles
// Displays the email in an iframe with desktop/mobile/full views
// ============================================================

import React, { useMemo, useState } from 'react';
import { Monitor, Smartphone, Maximize2 } from 'lucide-react';
import { EmailConfig } from '../types';
import { generateEmailHtml } from '../utils/generateEmail';

interface PreviewPanelProps {
  config: EmailConfig;
}

// Preview mode configurations
const previewModes = [
  { id: 'mobile' as const, icon: Smartphone, label: 'Mobile', width: '375px' },
  { id: 'desktop' as const, icon: Monitor, label: 'Desktop', width: '620px' },
  { id: 'full' as const, icon: Maximize2, label: 'Full Width', width: '100%' },
];

export const PreviewPanel: React.FC<PreviewPanelProps> = ({ config }) => {
  const [previewMode, setPreviewMode] = useState<'mobile' | 'desktop' | 'full'>('desktop');

  // Memoize the generated HTML to avoid unnecessary re-computation
  const emailHtml = useMemo(() => generateEmailHtml(config), [config]);

  const currentMode = previewModes.find(m => m.id === previewMode)!;

  return (
    <div className="h-full flex flex-col bg-gray-100/80">
      {/* Preview toolbar */}
      <div className="flex items-center justify-between px-4 py-2.5 bg-white border-b border-gray-200 shrink-0">
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-emerald-400"></div>
          <h3 className="font-semibold text-gray-700 text-sm">Live Preview</h3>
        </div>

        {/* Responsive toggle */}
        <div className="flex items-center gap-0.5 bg-gray-100 p-0.5 rounded-lg">
          {previewModes.map((mode) => {
            const isActive = previewMode === mode.id;
            return (
              <button
                key={mode.id}
                onClick={() => setPreviewMode(mode.id)}
                className={`flex items-center gap-1 px-2.5 py-1.5 rounded-md text-xs font-medium transition-all ${
                  isActive
                    ? 'bg-white text-gray-800 shadow-sm'
                    : 'text-gray-500 hover:text-gray-700'
                }`}
                title={mode.label}
              >
                <mode.icon size={13} />
                <span className="hidden lg:inline">{mode.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Preview frame */}
      <div className="flex-1 overflow-auto flex justify-center p-4">
        <div
          className="preview-frame bg-white rounded-xl shadow-lg overflow-hidden border border-gray-200 h-fit"
          style={{ width: currentMode.width, maxWidth: '100%' }}
        >
          {/* Browser chrome mockup */}
          <div className="flex items-center gap-1.5 px-3 py-2 bg-gray-100 border-b border-gray-200">
            <div className="w-2.5 h-2.5 rounded-full bg-red-400"></div>
            <div className="w-2.5 h-2.5 rounded-full bg-yellow-400"></div>
            <div className="w-2.5 h-2.5 rounded-full bg-green-400"></div>
            <div className="flex-1 ml-2 bg-white rounded-md px-3 py-1 text-[10px] text-gray-400 truncate border border-gray-200">
              {config.subject || 'Email Preview'}
            </div>
          </div>

          {/* Email iframe */}
          <iframe
            srcDoc={emailHtml}
            title="Email Preview"
            className="w-full border-0"
            style={{ minHeight: '700px', height: 'auto' }}
            sandbox="allow-same-origin"
          />
        </div>
      </div>

      {/* Footer info */}
      <div className="px-4 py-2 bg-white border-t border-gray-200 shrink-0">
        <p className="text-[10px] text-gray-400 text-center">
          Preview shows approximate rendering. Test in actual email clients before sending.
        </p>
      </div>
    </div>
  );
};
