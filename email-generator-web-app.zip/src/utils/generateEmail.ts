// ============================================================
// Email HTML Generator
// Produces clean, inline-CSS, email-client-compatible HTML
// Compatible with: Gmail, Outlook, Apple Mail, Yahoo Mail
// ============================================================

import { EmailConfig, EmailSection, socialPlatformColors } from '../types';

/**
 * Generate a section's HTML based on its type
 */
function generateSectionHtml(section: EmailSection, config: EmailConfig): string {
  const { fontFamily, buttonColor, buttonTextColor, themeColor } = config;

  switch (section.type) {
    // ---- TEXT SECTION ----
    case 'text': {
      const text = section.content.text || '';
      // If text contains HTML tags, use as-is; otherwise convert newlines to <br>
      const htmlContent = text.includes('<') ? text : text.split('\n').map(line => line || '&nbsp;').join('<br>');
      return `
          <!-- Text Section -->
          <tr>
            <td style="padding: 12px 40px; color: #333333; font-size: 16px; line-height: 1.7; font-family: ${fontFamily};" class="padding-mobile">
              ${htmlContent}
            </td>
          </tr>`;
    }

    // ---- IMAGE SECTION ----
    case 'image': {
      const src = section.content.src || '';
      if (!src) return '';
      return `
          <!-- Image Section -->
          <tr>
            <td style="padding: 12px 40px; text-align: center;" class="padding-mobile">
              <img src="${src}" alt="${section.content.alt || 'Image'}" style="max-width: 100%; height: auto; display: block; margin: 0 auto; border-radius: 6px; border: 0;" width="520">
            </td>
          </tr>`;
    }

    // ---- BUTTON SECTION ----
    case 'button': {
      const btnText = section.content.buttonText || 'Click Here';
      const btnUrl = section.content.url || '#';
      return `
          <!-- Button Section -->
          <tr>
            <td style="padding: 16px 40px; text-align: center;" class="padding-mobile">
              <table role="presentation" cellpadding="0" cellspacing="0" border="0" style="margin: 0 auto;">
                <tr>
                  <td style="border-radius: 6px; background-color: ${buttonColor};" align="center">
                    <!--[if mso]>
                    <v:roundrect xmlns:v="urn:schemas-microsoft-com:vml" xmlns:w="urn:schemas-microsoft-com:office:word" href="${btnUrl}" style="height:48px;v-text-anchor:middle;width:200px;" arcsize="13%" strokecolor="${buttonColor}" fillcolor="${buttonColor}">
                      <w:anchorlock/>
                      <center style="color:${buttonTextColor};font-family:Arial,sans-serif;font-size:16px;font-weight:bold;">${btnText}</center>
                    </v:roundrect>
                    <![endif]-->
                    <!--[if !mso]><!-->
                    <a href="${btnUrl}" target="_blank" style="display: inline-block; padding: 14px 36px; color: ${buttonTextColor}; text-decoration: none; font-family: ${fontFamily}; font-size: 16px; font-weight: 600; border-radius: 6px; background-color: ${buttonColor}; mso-padding-alt: 0; line-height: 1.2;">
                      ${btnText}
                    </a>
                    <!--<![endif]-->
                  </td>
                </tr>
              </table>
            </td>
          </tr>`;
    }

    // ---- DIVIDER SECTION ----
    case 'divider': {
      const dividerColor = section.content.color || '#e5e7eb';
      return `
          <!-- Divider Section -->
          <tr>
            <td style="padding: 8px 40px;" class="padding-mobile">
              <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">
                <tr>
                  <td style="border-top: 1px solid ${dividerColor}; font-size: 0; line-height: 0; height: 1px; mso-line-height-rule: exactly;">&nbsp;</td>
                </tr>
              </table>
            </td>
          </tr>`;
    }

    // ---- SOCIAL LINKS SECTION ----
    case 'social': {
      const links = (section.content.links || []).filter(l => l.url && l.url.trim());
      if (links.length === 0) return '';

      const socialHtml = links.map(link => {
        const color = socialPlatformColors[link.platform] || themeColor;
        return `
                    <td style="padding: 0 4px;" align="center">
                      <a href="${link.url}" target="_blank" style="display: inline-block; padding: 8px 16px; background-color: ${color}; color: #ffffff; text-decoration: none; font-family: Arial, sans-serif; font-size: 12px; font-weight: 600; border-radius: 4px; line-height: 1.2;">
                        ${link.platform}
                      </a>
                    </td>`;
      }).join('\n');

      return `
          <!-- Social Links Section -->
          <tr>
            <td style="padding: 16px 40px; text-align: center;" class="padding-mobile">
              <table role="presentation" cellpadding="0" cellspacing="0" border="0" style="margin: 0 auto;">
                <tr>
                  ${socialHtml}
                </tr>
              </table>
            </td>
          </tr>`;
    }

    default:
      return '';
  }
}

/**
 * Generate complete email HTML with inline CSS
 * Output is compatible with major email clients
 */
export function generateEmailHtml(config: EmailConfig): string {
  const {
    subject,
    heading,
    body,
    footerText,
    senderName,
    fontFamily,
    headerBgColor,
    logoImage,
    bannerImage,
    sections,
  } = config;

  // Generate dynamic sections HTML
  const sectionsHtml = sections.map(s => generateSectionHtml(s, config)).join('\n');

  // Generate preheader text (hidden preview text for email clients)
  const preheaderText = body.replace(/<[^>]*>/g, '').substring(0, 120);

  // Logo section
  const logoHtml = logoImage
    ? `
          <!-- Logo -->
          <tr>
            <td align="center" style="padding: 28px 40px 12px; background-color: ${headerBgColor};">
              <img src="${logoImage}" alt="Logo" style="max-width: 180px; max-height: 60px; height: auto; border: 0;" width="180">
            </td>
          </tr>`
    : '';

  // Banner section
  const bannerHtml = bannerImage
    ? `
          <!-- Banner Image -->
          <tr>
            <td style="padding: 0; line-height: 0; font-size: 0;">
              <img src="${bannerImage}" alt="Banner" style="width: 100%; max-width: 600px; height: auto; display: block; border: 0;" width="600">
            </td>
          </tr>`
    : '';

  // Complete email HTML
  return `<!DOCTYPE html>
<html lang="en" xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml" xmlns:o="urn:schemas-microsoft-com:office:office">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="x-apple-disable-message-reformatting">
  <meta name="format-detection" content="telephone=no,address=no,email=no,date=no,url=no">
  <title>${subject}</title>
  <!--[if mso]>
  <noscript>
    <xml>
      <o:OfficeDocumentSettings>
        <o:AllowPNG/>
        <o:PixelsPerInch>96</o:PixelsPerInch>
      </o:OfficeDocumentSettings>
    </xml>
  </noscript>
  <![endif]-->
  <style type="text/css">
    /* Email Reset Styles */
    body, table, td, a { -webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; }
    table, td { mso-table-lspace: 0pt; mso-table-rspace: 0pt; }
    img { -ms-interpolation-mode: bicubic; border: 0; height: auto; line-height: 100%; outline: none; text-decoration: none; }
    table { border-collapse: collapse !important; }
    body { height: 100% !important; margin: 0 !important; padding: 0 !important; width: 100% !important; }
    a[x-apple-data-detectors] { color: inherit !important; text-decoration: none !important; font-size: inherit !important; font-family: inherit !important; font-weight: inherit !important; line-height: inherit !important; }
    /* Responsive Styles */
    @media only screen and (max-width: 620px) {
      .email-container { width: 100% !important; max-width: 100% !important; }
      .fluid-img { width: 100% !important; max-width: 100% !important; height: auto !important; }
      .stack-column { display: block !important; width: 100% !important; max-width: 100% !important; }
      .padding-mobile { padding-left: 20px !important; padding-right: 20px !important; }
      .no-padding-mobile { padding-left: 0 !important; padding-right: 0 !important; }
      h1 { font-size: 22px !important; line-height: 1.3 !important; }
    }
  </style>
</head>
<body style="margin: 0; padding: 0; background-color: #f4f4f7; font-family: ${fontFamily}; -webkit-font-smoothing: antialiased; -moz-osx-font-smoothing: grayscale; word-spacing: normal;">

  <!-- Hidden Preheader Text -->
  <div style="display: none; font-size: 1px; color: #f4f4f7; line-height: 1px; max-height: 0px; max-width: 0px; opacity: 0; overflow: hidden; mso-hide: all;">
    ${preheaderText}&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;
  </div>

  <!-- Email Wrapper -->
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="background-color: #f4f4f7; width: 100%;">
    <tr>
      <td align="center" valign="top" style="padding: 30px 10px;">
        <!--[if mso]>
        <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="600" align="center">
        <tr>
        <td>
        <![endif]-->

        <!-- Email Container -->
        <table role="presentation" class="email-container" cellpadding="0" cellspacing="0" border="0" width="600" align="center" style="max-width: 600px; width: 100%; margin: 0 auto; background-color: #ffffff; border-radius: 8px; overflow: hidden; box-shadow: 0 2px 12px rgba(0,0,0,0.06);">

          ${logoHtml}
          ${bannerHtml}

          <!-- Header / Heading -->
          <tr>
            <td style="padding: 40px 40px 30px; background-color: ${headerBgColor}; text-align: center;" class="padding-mobile">
              <h1 style="margin: 0; color: #ffffff; font-size: 26px; font-weight: 700; line-height: 1.35; font-family: ${fontFamily}; letter-spacing: -0.02em;">
                ${heading}
              </h1>
            </td>
          </tr>

          <!-- Body Content -->
          <tr>
            <td style="padding: 32px 40px 20px; color: #333333; font-size: 16px; line-height: 1.7; font-family: ${fontFamily};" class="padding-mobile">
              ${body}
            </td>
          </tr>

          ${sectionsHtml}

          <!-- Footer -->
          <tr>
            <td style="padding: 28px 40px; background-color: #f8f9fa; border-top: 1px solid #eaeef3;" class="padding-mobile">
              <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">
                <tr>
                  <td align="center" style="color: #999999; font-size: 12px; line-height: 1.6; font-family: ${fontFamily};">
                    <p style="margin: 0 0 6px; color: #777777;">${footerText}</p>
                    <p style="margin: 0; color: #aaaaaa; font-size: 11px;">Sent by ${senderName}</p>
                  </td>
                </tr>
              </table>
            </td>
          </tr>

        </table>
        <!-- / Email Container -->

        <!--[if mso]>
        </td>
        </tr>
        </table>
        <![endif]-->
      </td>
    </tr>
  </table>
  <!-- / Email Wrapper -->

</body>
</html>`;
}
