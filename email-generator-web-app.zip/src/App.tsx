// ============================================================
// App Component — Email Design Generator
// Main application with split-screen editor/preview layout
// Features: Templates, Rich Text, Drag-and-Drop, Live Preview
// ============================================================

import { useState, useCallback, useEffect } from 'react';
import { Mail, Monitor, PenLine } from 'lucide-react';
import { EmailConfig, defaultEmailConfig } from './types';
import { EditorPanel } from './components/EditorPanel';
import { PreviewPanel } from './components/PreviewPanel';

function App() {
  const [config, setConfig] = useState<EmailConfig>(defaultEmailConfig);
  const [toast, setToast] = useState<{ message: string; id: number } | null>(null);
  const [mobileView, setMobileView] = useState<'editor' | 'preview'>('editor');

  // ---- Toast notification system ----
  const showToast = useCallback((message: string) => {
    const id = Date.now();
    setToast({ message, id });
  }, []);

  // Auto-dismiss toast after 3 seconds
  useEffect(() => {
    if (!toast) return;
    const timer = setTimeout(() => setToast(null), 3000);
    return () => clearTimeout(timer);
  }, [toast]);

  return (
    <div className="h-screen flex flex-col bg-gray-50 overflow-hidden">
      {/* ---- HEADER ---- */}
      <header className="bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 text-white px-4 sm:px-6 py-3 flex items-center justify-between shrink-0 border-b border-slate-700/50">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center shadow-lg shadow-blue-600/20">
            <Mail size={16} className="text-white" />
          </div>
          <div>
            <h1 className="text-sm sm:text-base font-bold tracking-tight leading-none">
              Email Design Generator
            </h1>
            <p className="text-[10px] text-slate-400 hidden sm:block">Professional HTML Email Builder</p>
          </div>
        </div>

        {/* Mobile view toggle */}
        <div className="flex md:hidden items-center gap-1 bg-slate-700/50 p-0.5 rounded-lg">
          <button
            onClick={() => setMobileView('editor')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-all ${
              mobileView === 'editor'
                ? 'bg-blue-600 text-white'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <PenLine size={12} />
            Editor
          </button>
          <button
            onClick={() => setMobileView('preview')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-all ${
              mobileView === 'preview'
                ? 'bg-blue-600 text-white'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Monitor size={12} />
            Preview
          </button>
        </div>

        {/* Desktop badge */}
        <div className="hidden md:flex items-center gap-2">
          <span className="text-[10px] text-slate-500 bg-slate-800 px-2.5 py-1 rounded-full border border-slate-700">
            Gmail • Outlook • Apple Mail Compatible
          </span>
        </div>
      </header>

      {/* ---- MAIN CONTENT ---- */}
      <div className="flex-1 flex overflow-hidden">
        {/* Editor Panel (Left) */}
        <div
          className={`w-full md:w-[420px] lg:w-[460px] shrink-0 border-r border-gray-200 ${
            mobileView !== 'editor' ? 'hidden md:block' : ''
          }`}
        >
          <EditorPanel config={config} setConfig={setConfig} onToast={showToast} />
        </div>

        {/* Preview Panel (Right) */}
        <div
          className={`flex-1 min-w-0 ${
            mobileView !== 'preview' ? 'hidden md:block' : ''
          }`}
        >
          <PreviewPanel config={config} />
        </div>
      </div>

      {/* ---- TOAST NOTIFICATION ---- */}
      {toast && (
        <div
          key={toast.id}
          className="fixed bottom-6 right-6 z-50 toast-enter"
        >
          <div className="bg-slate-800 text-white px-5 py-3 rounded-xl shadow-2xl shadow-black/20 flex items-center gap-2 text-sm font-medium border border-slate-700/50 backdrop-blur-sm">
            <span>{toast.message}</span>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
