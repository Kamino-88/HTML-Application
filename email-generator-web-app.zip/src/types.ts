// ============================================================
// Type Definitions for Email Design Generator
// ============================================================

/** Available pre-designed template types */
export type TemplateType = 'corporate' | 'minimal' | 'marketing' | 'institutional';

/** Available content section types for drag-and-drop builder */
export type SectionType = 'text' | 'image' | 'button' | 'divider' | 'social';

/** Individual content section in the email body */
export interface EmailSection {
  id: string;
  type: SectionType;
  content: {
    text?: string;
    src?: string;
    alt?: string;
    url?: string;
    buttonText?: string;
    color?: string;
    links?: Array<{ platform: string; url: string }>;
  };
}

/** Complete email configuration state */
export interface EmailConfig {
  subject: string;
  heading: string;
  body: string;
  footerText: string;
  senderName: string;
  themeColor: string;
  fontFamily: string;
  headerBgColor: string;
  buttonColor: string;
  buttonTextColor: string;
  logoImage: string;
  bannerImage: string;
  template: TemplateType;
  sections: EmailSection[];
}

/** Template preset configuration */
export interface TemplatePreset {
  id: TemplateType;
  name: string;
  description: string;
  themeColor: string;
  fontFamily: string;
  headerBgColor: string;
  buttonColor: string;
  buttonTextColor: string;
}

/** Default email configuration */
export const defaultEmailConfig: EmailConfig = {
  subject: 'Monthly Newsletter — January 2025',
  heading: 'Welcome to Our Newsletter',
  body: '<p>Thank you for being a valued subscriber. We\'re excited to share the latest updates and news with you.</p><p>Here\'s what\'s new this month:</p><ul><li>Product updates and improvements</li><li>Upcoming events and webinars</li><li>Exclusive offers for subscribers</li></ul><p>We appreciate your continued support and look forward to keeping you informed.</p>',
  footerText: '© 2025 Your Company. All rights reserved. | 123 Business Ave, Suite 100, City, ST 12345',
  senderName: 'Your Company',
  themeColor: '#2563eb',
  fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
  headerBgColor: '#1e40af',
  buttonColor: '#2563eb',
  buttonTextColor: '#ffffff',
  logoImage: '',
  bannerImage: '',
  template: 'corporate',
  sections: [],
};

/** Pre-designed template presets */
export const templatePresets: TemplatePreset[] = [
  {
    id: 'corporate',
    name: 'Corporate',
    description: 'Professional blue theme for business communications',
    themeColor: '#1e40af',
    fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
    headerBgColor: '#1e3a5f',
    buttonColor: '#1e40af',
    buttonTextColor: '#ffffff',
  },
  {
    id: 'minimal',
    name: 'Minimal',
    description: 'Clean and simple design with elegant accents',
    themeColor: '#374151',
    fontFamily: "'Helvetica Neue', Helvetica, Arial, sans-serif",
    headerBgColor: '#111827',
    buttonColor: '#374151',
    buttonTextColor: '#ffffff',
  },
  {
    id: 'marketing',
    name: 'Marketing',
    description: 'Bold and vibrant for promotional campaigns',
    themeColor: '#dc2626',
    fontFamily: "Arial, Helvetica, sans-serif",
    headerBgColor: '#991b1b',
    buttonColor: '#f59e0b',
    buttonTextColor: '#1f2937',
  },
  {
    id: 'institutional',
    name: 'Institutional',
    description: 'Formal design for educational & government use',
    themeColor: '#065f46',
    fontFamily: "Cambria, Georgia, serif",
    headerBgColor: '#064e3b',
    buttonColor: '#065f46',
    buttonTextColor: '#ffffff',
  },
];

/** Font options for the design picker */
export const fontOptions = [
  { label: 'Segoe UI', value: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif" },
  { label: 'Arial', value: "Arial, Helvetica, sans-serif" },
  { label: 'Helvetica Neue', value: "'Helvetica Neue', Helvetica, Arial, sans-serif" },
  { label: 'Georgia', value: "Georgia, 'Times New Roman', serif" },
  { label: 'Times New Roman', value: "'Times New Roman', Times, serif" },
  { label: 'Trebuchet MS', value: "'Trebuchet MS', Helvetica, sans-serif" },
  { label: 'Verdana', value: "Verdana, Geneva, sans-serif" },
  { label: 'Cambria', value: "Cambria, Georgia, serif" },
  { label: 'Tahoma', value: "Tahoma, Geneva, sans-serif" },
  { label: 'Courier New', value: "'Courier New', Courier, monospace" },
];

/** Social media platform colors for email rendering */
export const socialPlatformColors: Record<string, string> = {
  Facebook: '#1877F2',
  Twitter: '#1DA1F2',
  LinkedIn: '#0A66C2',
  Instagram: '#E4405F',
  YouTube: '#FF0000',
};
